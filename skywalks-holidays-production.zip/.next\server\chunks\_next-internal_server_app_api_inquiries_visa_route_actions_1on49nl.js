module.exports=[86889,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inquiries_visa_route_actions_1on49nl.js.map