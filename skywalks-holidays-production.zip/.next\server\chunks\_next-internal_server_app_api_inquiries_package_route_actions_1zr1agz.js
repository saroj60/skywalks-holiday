module.exports=[63263,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inquiries_package_route_actions_1zr1agz.js.map