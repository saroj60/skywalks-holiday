module.exports=[29732,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_departures_%5Bid%5D_route_actions_1wbdsc7.js.map