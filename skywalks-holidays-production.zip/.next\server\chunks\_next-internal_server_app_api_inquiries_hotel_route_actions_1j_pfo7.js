module.exports=[51583,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inquiries_hotel_route_actions_1j_pfo7.js.map