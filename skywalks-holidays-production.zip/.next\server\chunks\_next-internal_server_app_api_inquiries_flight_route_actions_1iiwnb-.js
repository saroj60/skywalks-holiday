module.exports=[50554,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inquiries_flight_route_actions_1iiwnb-.js.map