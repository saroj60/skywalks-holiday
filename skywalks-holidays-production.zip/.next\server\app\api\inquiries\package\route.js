var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/package/route.js")
R.c("server/chunks/[root-of-the-server]__20_30gw._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_package_route_actions_1zr1agz.js")
R.m(38867)
module.exports=R.m(38867).exports
