var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/departures/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0j5yj-s._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_departures_[id]_route_actions_1wbdsc7.js")
R.m(10898)
module.exports=R.m(10898).exports
