var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/inquiries/route.js")
R.c("server/chunks/[root-of-the-server]__0-lgvt8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_inquiries_route_actions_0h_ilbh.js")
R.m(44648)
module.exports=R.m(44648).exports
