var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/hotels/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__02art30._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_hotels_[id]_route_actions_01uiq-k.js")
R.m(84613)
module.exports=R.m(84613).exports
