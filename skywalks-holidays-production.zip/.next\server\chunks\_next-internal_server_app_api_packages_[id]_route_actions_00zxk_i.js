module.exports=[32877,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_packages_%5Bid%5D_route_actions_00zxk_i.js.map