var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/hotels/route.js")
R.c("server/chunks/[root-of-the-server]__0jam21d._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_hotels_route_actions_14mbpel.js")
R.m(22720)
module.exports=R.m(22720).exports
