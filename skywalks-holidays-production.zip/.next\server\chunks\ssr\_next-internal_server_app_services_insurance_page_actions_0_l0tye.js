module.exports=[97598,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_insurance_page_actions_0_l0tye.js.map