module.exports=[66754,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_hotels_page_actions_1h7e9jn.js.map