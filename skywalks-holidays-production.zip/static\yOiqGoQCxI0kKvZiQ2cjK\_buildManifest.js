self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/flights",
        "destination": "/services/flights"
      },
      {
        "source": "/hotels",
        "destination": "/services/hotels"
      },
      {
        "source": "/holiday-packages",
        "destination": "/services/packages/international"
      },
      {
        "source": "/visa-services",
        "destination": "/services/visa"
      },
      {
        "source": "/bus-tickets",
        "destination": "/services/bus"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()