var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__1d-v8i_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_me_route_actions_026u7eq.js")
R.m(81961)
module.exports=R.m(81961).exports
