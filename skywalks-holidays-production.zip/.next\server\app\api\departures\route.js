var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/departures/route.js")
R.c("server/chunks/[root-of-the-server]__1-aojig._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_departures_route_actions_1w_q1bz.js")
R.m(88822)
module.exports=R.m(88822).exports
