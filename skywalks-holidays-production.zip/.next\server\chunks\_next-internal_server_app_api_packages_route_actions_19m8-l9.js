module.exports=[43466,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_packages_route_actions_19m8-l9.js.map