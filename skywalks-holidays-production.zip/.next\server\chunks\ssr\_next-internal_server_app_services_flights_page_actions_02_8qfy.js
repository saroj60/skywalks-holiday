module.exports=[32889,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_flights_page_actions_02_8qfy.js.map