module.exports=[12856,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_flights_%5Bid%5D_route_actions_0fp0umb.js.map