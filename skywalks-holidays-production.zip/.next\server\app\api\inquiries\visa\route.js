var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/visa/route.js")
R.c("server/chunks/[root-of-the-server]__0e-57z_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_visa_route_actions_1on49nl.js")
R.m(18173)
module.exports=R.m(18173).exports
