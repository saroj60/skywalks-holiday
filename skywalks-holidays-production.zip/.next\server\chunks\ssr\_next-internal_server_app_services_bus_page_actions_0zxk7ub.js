module.exports=[1076,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_bus_page_actions_0zxk7ub.js.map