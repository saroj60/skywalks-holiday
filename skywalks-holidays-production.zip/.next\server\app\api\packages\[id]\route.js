var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/packages/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1h_u73a._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_packages_[id]_route_actions_00zxk_i.js")
R.m(24813)
module.exports=R.m(24813).exports
