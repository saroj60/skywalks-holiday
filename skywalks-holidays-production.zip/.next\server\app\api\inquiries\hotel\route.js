var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/hotel/route.js")
R.c("server/chunks/[root-of-the-server]__1e4fi8o._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_hotel_route_actions_1j_pfo7.js")
R.m(75014)
module.exports=R.m(75014).exports
