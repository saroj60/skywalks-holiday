var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/flight/route.js")
R.c("server/chunks/[root-of-the-server]__0hmmrmf._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_flight_route_actions_1iiwnb-.js")
R.m(36853)
module.exports=R.m(36853).exports
