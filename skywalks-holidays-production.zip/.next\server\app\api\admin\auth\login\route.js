var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0j9npju._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_login_route_actions_1a__1v0.js")
R.m(40801)
module.exports=R.m(40801).exports
