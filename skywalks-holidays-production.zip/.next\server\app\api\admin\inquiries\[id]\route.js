var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/inquiries/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ke2wdp._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_inquiries_[id]_route_actions_0q---s3.js")
R.m(72986)
module.exports=R.m(72986).exports
