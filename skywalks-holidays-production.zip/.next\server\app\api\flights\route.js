var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/flights/route.js")
R.c("server/chunks/[root-of-the-server]__1awi-fu._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_flights_route_actions_0pcx-ky.js")
R.m(1971)
module.exports=R.m(1971).exports
