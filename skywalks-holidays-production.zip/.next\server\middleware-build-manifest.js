globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wGFJx8FhArUaKjQWdUMew/_buildManifest.js",
    "static/wGFJx8FhArUaKjQWdUMew/_ssgManifest.js",
    "static/wGFJx8FhArUaKjQWdUMew/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/3450qyhportkm.js",
    "static/chunks/3kmozkq6tgqnz.js",
    "static/chunks/3bawhkhjtuhib.js",
    "static/chunks/turbopack-37sobf73wb686.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
