module.exports=[8330,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_custom_page_actions_0xs5nzs.js.map