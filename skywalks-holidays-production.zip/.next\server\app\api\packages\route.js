var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/packages/route.js")
R.c("server/chunks/[root-of-the-server]__06hgwg0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__10qhjuo._.js")
R.c("server/chunks/_next-internal_server_app_api_packages_route_actions_19m8-l9.js")
R.m(98597)
module.exports=R.m(98597).exports
