module.exports=[77689,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_packages_domestic_page_actions_0wczxdi.js.map