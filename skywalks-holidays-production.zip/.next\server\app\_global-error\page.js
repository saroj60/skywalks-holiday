var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1f2jx51._.js")
R.c("server/chunks/ssr/node_modules_next_dist_1n3w9lb._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0_vqsnh._.js")
R.c("server/chunks/ssr/[root-of-the-server]__174cgu_._.js")
R.c("server/chunks/ssr/node_modules_next_dist_client_components_builtin_global-error_0q-w892.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0zi5s8-.js")
R.m(91654)
module.exports=R.m(91654).exports
