var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/bus/route.js")
R.c("server/chunks/[root-of-the-server]__0-u3mgq._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_bus_route_actions_19ptj14.js")
R.m(94659)
module.exports=R.m(94659).exports
