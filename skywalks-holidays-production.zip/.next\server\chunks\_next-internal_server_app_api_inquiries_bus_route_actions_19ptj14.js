module.exports=[84210,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inquiries_bus_route_actions_19ptj14.js.map